
public class Torre extends Ficha {

	public Torre(String forma, int posicionX, int posicionY, int movimiento) {
		super(forma, posicionX, posicionY, movimiento);
		// TODO Auto-generated constructor stub
	}

}
