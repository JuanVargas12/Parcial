
public abstract class Ficha {
	public String forma;
	public int posicionX;
	public int posicionY;
	public int movimiento;

public String getForma() {
		return forma;
	}


	public void setForma(String forma) {
		this.forma = forma;
	}


	public int getMovimiento() {
		return movimiento;
	}


	public void setMovimiento(int movimiento) {
		this.movimiento = movimiento;
	}


public Ficha(String forma, int posicionX,int posicionY,int movimiento) {
	this.forma = forma;
	this.posicionX = posicionX;
	this.posicionY = posicionY;
	this.movimiento = movimiento;
	
	}
}