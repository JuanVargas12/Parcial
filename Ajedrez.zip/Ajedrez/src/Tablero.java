
public class Tablero {
	public int casillaX; // 8
	public int casillaY; // 8
	private Ficha Ficha;
	
}
